import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import "dotenv/config";

const app = express();
app.use(helmet());
app.use(express.json({limit:"15mb"}));
app.use("/api/", rateLimit({windowMs:60_000, limit:20, standardHeaders:true, legacyHeaders:false}));

app.get("/health", (_req,res)=>res.json({ok:true,service:"Notebook Hisab API"}));

app.post("/api/extract", async (req,res)=>{
  try {
    const key=process.env.GEMINI_API_KEY;
    if(!key) return res.status(503).json({error:"Server Gemini API key is not configured"});
    const {imageBase64,mimeType="image/jpeg",columns}=req.body ?? {};
    const count=Number(columns);
    if(!imageBase64 || ![4,5].includes(count)) return res.status(400).json({error:"imageBase64 and columns=4 or 5 are required"});
    if(imageBase64.length>12_000_000) return res.status(413).json({error:"Image is too large"});
    const prompt=`You are a careful handwritten ledger transcription system. The image is a notebook page with exactly ${count} vertical amount columns. Read only monetary/numeric entries in each column, top to bottom. NEVER move a number between columns. Preserve row alignment across columns. Do not infer, repair, or guess unclear digits. For an unreadable/ambiguous cell, return value:null, uncertain:true, confidence:0 and a short reason. Ignore headings, dates, names, page numbers, totals already printed, and non-amount text. Do not invent missing rows. Return ONLY valid JSON matching this schema: {"columns":[{"index":1,"values":[{"value":"125","confidence":0.98,"uncertain":false,"reason":""}]}]}. Provide exactly ${count} column objects, indices 1..${count}. Values must be strings containing digits only (no currency symbol, commas, decimals, signs) or null. Confidence is 0..1. Mark anything below 0.85 uncertain.`;
    const model=process.env.GEMINI_MODEL || "gemini-2.5-flash";
    const api=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
    const response=await fetch(api,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
      contents:[{parts:[{text:prompt},{inlineData:{mimeType,data:imageBase64}}]}],
      generationConfig:{temperature:0,responseMimeType:"application/json"}
    })});
    const data=await response.json();
    if(!response.ok) return res.status(502).json({error:"Gemini request failed",detail:data.error?.message || "Unknown provider error"});
    const raw=data.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("") || "";
    const parsed=JSON.parse(raw.replace(/^```(?:json)?\s*/,"").replace(/\s*```$/,""));
    if(!Array.isArray(parsed.columns) || parsed.columns.length!==count) throw new Error("Gemini returned an unexpected column structure");
    for(let c=0;c<count;c++){
      parsed.columns[c].values=(parsed.columns[c].values||[]).map(v=>{
        const valid=typeof v.value==="string" && /^\d+$/.test(v.value);
        return {value:valid?v.value:null,confidence:Number(v.confidence)||0,uncertain:!valid || v.uncertain===true || Number(v.confidence)<0.85,reason:v.reason||""};
      });
    }
    res.json(parsed);
  } catch(e) {
    res.status(500).json({error:"Could not extract notebook numbers",detail:e.message});
  }
});
const port=process.env.PORT || 8080;
app.listen(port,()=>console.log(`Notebook Hisab API listening on ${port}`));
