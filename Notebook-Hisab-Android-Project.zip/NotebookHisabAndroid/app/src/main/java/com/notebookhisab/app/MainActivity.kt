package com.notebookhisab.app

import android.app.Activity
import android.app.AlertDialog
import android.app.ProgressDialog
import android.os.Bundle
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import android.util.Base64

class MainActivity : Activity() {
    private val exec = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var serverField: EditText
    private lateinit var countSpinner: Spinner
    private var columnCount = 4
    private var cells = mutableListOf<MutableList<String>>()
    private var uncertain = mutableListOf<MutableList<Boolean>>()
    private var sourceBitmap: Bitmap? = null
    private val prefs by lazy { getSharedPreferences("hisab_local", MODE_PRIVATE) }
    private val blue = Color.rgb(23,105,170)
    private val ink = Color.rgb(25,42,58)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cells = mutableListOf(MutableList(columnCount) { "" })
        uncertain = mutableListOf(MutableList(columnCount) { false })
        buildUi()
    }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=15f,bold:Boolean=false,color:Int=ink):TextView =
        TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold) setTypeface(null,1); setPadding(dp(4),dp(5),dp(4),dp(5)) }
    private fun button(s:String, action:()->Unit): Button = Button(this).apply {
        text=s; isAllCaps=false; setOnClickListener { action() }
    }
    private fun buildUi() {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(246,249,252)); setPadding(dp(14),dp(10),dp(14),dp(10)) }
        val head=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(4),dp(8),dp(4),dp(10)) }
        head.addView(text("📒 Notebook Hisab Calculator",22f,true,blue))
        head.addView(text("नोटबुक के हर कॉलम का सही जोड़",14f,false,Color.DKGRAY))
        root.addView(head)
        val scroll=ScrollView(this)
        content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        content.addView(text("1. कॉलम चुनें",16f,true))
        countSpinner=Spinner(this)
        countSpinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("4 कॉलम","5 कॉलम"))
        countSpinner.setSelection(0)
        countSpinner.onItemSelectedListener=object: android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view:View?, position:Int,id:Long) {
                val next=if(position==0)4 else 5
                if(next!=columnCount){ columnCount=next; cells.forEach { while(it.size<columnCount)it.add(""); while(it.size>columnCount)it.removeAt(it.lastIndex) }; uncertain.forEach { while(it.size<columnCount)it.add(false); while(it.size>columnCount)it.removeAt(it.lastIndex) }; renderRows() }
            }
        }
        content.addView(countSpinner)
        content.addView(text("2. नोटबुक की फोटो चुनें",16f,true))
        content.addView(button("📷 गैलरी से फोटो चुनें") { pickImage() })
        content.addView(button("कैमरे से फोटो लें") { takePhoto() })
        content.addView(button("Gemini से अंक पढ़ें") { scanWithGemini() })
        content.addView(text("सर्वर URL (एक बार सेट करें)",13f,true))
        serverField=EditText(this).apply {
            hint="https://your-secure-server.example"
            setSingleLine(true)
            setText(prefs.getString("server",""))
            textSize=13f
        }
        content.addView(serverField)
        content.addView(text("3. निकाले गए अंकों की जाँच / बदलाव",16f,true))
        content.addView(text("पीले ⚠️ वाले अंक ध्यान से जाँचें। खाली अंक का अनुमान नहीं लगाया जाएगा।",12f,false,Color.rgb(170,90,0)))
        content.addView(button("+ नई पंक्ति जोड़ें") { addRow() })
        content.addView(button("अंकों का जोड़ निकालें") { renderRows() })
        renderRows()
        content.addView(button("💾 हिसाब सेव करें") { saveHistory() })
        content.addView(button("📄 PDF एक्सपोर्ट") { exportPdf() })
        content.addView(button("🖼️ इमेज एक्सपोर्ट") { exportImage() })
        content.addView(button("📚 सेव हिस्ट्री देखें") { showHistory() })
    }
    private fun pickImage() {
        val i=Intent(Intent.ACTION_GET_CONTENT).apply { type="image/*" }
        startActivityForResult(i,101)
    }
    private fun takePhoto() {
        val i=Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if(i.resolveActivity(packageManager)!=null) startActivityForResult(i,102)
        else toast("इस फोन में कैमरा ऐप उपलब्ध नहीं है")
    }
    @Deprecated("Legacy activity result for broad Android compatibility")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode==Activity.RESULT_OK && requestCode==102) {
            sourceBitmap=data?.extras?.get("data") as? Bitmap
            toast(if(sourceBitmap!=null) "कैमरे की फोटो मिल गई" else "कैमरा फोटो नहीं मिली")
        } else if(requestCode==101 && resultCode==Activity.RESULT_OK) {
            val uri=data?.data ?: return
            try { contentResolver.openInputStream(uri)?.use { sourceBitmap=BitmapFactory.decodeStream(it) }; Toast.makeText(this,"फोटो चुन ली गई",Toast.LENGTH_SHORT).show() }
            catch(e:Exception){ toast("फोटो नहीं खुली: ${e.message}") }
        }
    }
    private fun scanWithGemini() {
        val bmp=sourceBitmap
        if(bmp==null){toast("पहले नोटबुक की फोटो चुनें");return}
        val base=serverField.text.toString().trim().trimEnd('/')
        if(!base.startsWith("https://")){toast("सुरक्षित HTTPS सर्वर URL डालें");return}
        prefs.edit().putString("server",base).apply()
        val bytes=ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG,85,it) }.toByteArray()
        val b64=Base64.encodeToString(bytes,Base64.NO_WRAP)
        val progress=ProgressDialog(this).apply { setMessage("हस्तलिखित अंक पढ़े जा रहे हैं…");setCancelable(false);show() }
        exec.execute {
            try {
                val conn=(URL("$base/api/extract").openConnection() as HttpURLConnection).apply {
                    requestMethod="POST"; connectTimeout=30000; readTimeout=90000; doOutput=true
                    setRequestProperty("Content-Type","application/json")
                }
                val payload=JSONObject().put("imageBase64",b64).put("mimeType","image/jpeg").put("columns",columnCount)
                conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val stream=if(conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response=stream.bufferedReader().use{it.readText()}
                if(conn.responseCode !in 200..299) throw Exception(response)
                val obj=JSONObject(response); val arr=obj.getJSONArray("columns")
                val newCells=mutableListOf<MutableList<String>>()
                val newFlags=mutableListOf<MutableList<Boolean>>()
                val rowCount=(0 until columnCount).maxOf { arr.getJSONObject(it).getJSONArray("values").length() }
                for(r in 0 until rowCount) {
                    val row=MutableList(columnCount){""}; val flags=MutableList(columnCount){false}
                    for(c in 0 until columnCount) {
                        val col=arr.getJSONObject(c); val values=col.getJSONArray("values")
                        if(r<values.length()) {
                            val item=values.getJSONObject(r)
                            row[c]=if(item.isNull("value")) "" else item.optString("value","")
                            flags[c]=item.optBoolean("uncertain",true) || item.optDouble("confidence",0.0)<0.85
                        }
                    }
                    newCells.add(row);newFlags.add(flags)
                }
                runOnUiThread {
                    cells=newCells;uncertain=newFlags;progress.dismiss();renderRows()
                    toast("स्कैन पूरा। ⚠️ निशान वाले अंक जाँचें।")
                }
            } catch(e:Exception){runOnUiThread{progress.dismiss();toast("स्कैन असफल: ${e.message}")}}
        }
    }
    private fun addRow(){ cells.add(MutableList(columnCount){""}); uncertain.add(MutableList(columnCount){false}); renderRows() }
    private fun totals():List<Long?> = (0 until columnCount).map { c ->
        var sum=0L
        for(row in cells){ val s=row.getOrNull(c)?.trim().orEmpty(); if(s.isNotEmpty()){ val n=s.replace(",","").toLongOrNull() ?: return@map null; sum+=n } }
        sum
    }
    private fun renderRows() {
        val old=content.findViewWithTag<View>("rows_container")
        if(old!=null) content.removeView(old)
        val table=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; tag="rows_container" }
        val header=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setBackgroundColor(Color.rgb(225,237,248)) }
        for(c in 0 until columnCount) header.addView(text("कॉलम ${c+1}",12f,true,blue),LinearLayout.LayoutParams(0,-2,1f))
        table.addView(header)
        cells.forEachIndexed { r,row ->
            val line=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
            for(c in 0 until columnCount) {
                val edit=EditText(this).apply {
                    setSingleLine(true); textSize=14f; hint="अंक"; setText(row[c])
                    setPadding(dp(4),dp(6),dp(4),dp(6))
                    if(uncertain.getOrNull(r)?.getOrNull(c)==true) setBackgroundColor(Color.rgb(255,244,204))
                    addTextChangedListener(SimpleWatcher { value -> cells.getOrNull(r)?.set(c,value); updateTotalsOnly() })
                }
                line.addView(edit,LinearLayout.LayoutParams(0,dp(48),1f))
            }
            table.addView(line)
            val sep=View(this).apply { setBackgroundColor(Color.rgb(225,230,235)) }
            table.addView(sep,LinearLayout.LayoutParams(-1,dp(1)))
        }
        val sumLine=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setBackgroundColor(Color.rgb(220,241,230)) }
        totals().forEachIndexed { i,v -> sumLine.addView(text(v?.toString() ?: "जाँचें",14f,true,Color.rgb(20,110,65)),LinearLayout.LayoutParams(0,-2,1f)) }
        sumLine.tag="sum_line";table.addView(sumLine)
        val grand=totals().fold(0L){acc,v->acc+(v?:0L)}
        table.addView(text(if(totals().any { it==null }) "कुल योग (Grand Total): जाँच आवश्यक" else "कुल योग (Grand Total): ₹$grand",18f,true,blue))
        content.addView(table,content.indexOfChild(content.findViewWithTag<View>("rows_container")).let{LinearLayout.LayoutParams(-1,-2)})
    }
    private fun updateTotalsOnly(){ /* totals refresh on the next calculate action; edits remain live */ }
    private fun saveHistory() {
        val item=JSONObject().put("time",System.currentTimeMillis()).put("columns",columnCount)
        val rows=JSONArray();cells.forEach{row->rows.put(JSONArray(row))}
        item.put("rows",rows)
        val hist=JSONArray(prefs.getString("history","[]"))
        hist.put(item);prefs.edit().putString("history",hist.toString()).apply()
        toast("हिसाब फोन में सेव हो गया")
    }
    private fun showHistory() {
        val hist=JSONArray(prefs.getString("history","[]"))
        if(hist.length()==0){toast("अभी कोई हिस्ट्री सेव नहीं है");return}
        val labels=(0 until hist.length()).reversed().map { i ->
            val x=hist.getJSONObject(i); val date=java.text.SimpleDateFormat("dd-MM-yyyy HH:mm",java.util.Locale("en","IN")).format(java.util.Date(x.getLong("time")))
            "$date • ${x.getInt("columns")} कॉलम"
        }
        AlertDialog.Builder(this).setTitle("सेव हिस्ट्री").setItems(labels.toTypedArray()){_,which->
            val index=hist.length()-1-which;val item=hist.getJSONObject(index);columnCount=item.getInt("columns");countSpinner.setSelection(if(columnCount==4)0 else 1)
            val a=item.getJSONArray("rows");cells=mutableListOf();uncertain=mutableListOf()
            for(i in 0 until a.length()){val rr=a.getJSONArray(i);cells.add(MutableList(columnCount){c->rr.optString(c,"")});uncertain.add(MutableList(columnCount){false})}
            renderRows()
        }.setNegativeButton("बंद",null).show()
    }
    private fun exportPdf() {
        val doc=PdfDocument(); val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create())
        val p=Paint().apply{color=ink;textSize=16f}
        page.canvas.drawText("Notebook Hisab Calculator",35f,45f,p)
        p.textSize=12f
        val w=520f/columnCount
        for(c in 0 until columnCount) page.canvas.drawText("Column ${c+1}",35f+c*w,80f,p)
        cells.forEachIndexed{r,row-> for(c in 0 until columnCount) page.canvas.drawText(row[c].take(14),35f+c*w,110f+r*24f,p)}
        val t=totals();for(c in 0 until columnCount) page.canvas.drawText(t[c]?.toString() ?: "REVIEW",35f+c*w,130f+cells.size*24f,p)
        p.textSize=16f;page.canvas.drawText(if(t.any{it==null}) "Grand Total: REVIEW REQUIRED" else "Grand Total: ${t.fold(0L){a,v->a+(v?:0L)}}",35f,170f+cells.size*24f,p)
        doc.finishPage(page)
        try {
            val values=android.content.ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,"Notebook-Hisab-${System.currentTimeMillis()}.pdf");put(MediaStore.Downloads.MIME_TYPE,"application/pdf");put(MediaStore.Downloads.RELATIVE_PATH,"Download")}
            val uri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values)!!
            contentResolver.openOutputStream(uri)!!.use{doc.writeTo(it)}
            toast("PDF Downloads फोल्डर में सेव हुआ")
        }catch(e:Exception){toast("PDF सेव नहीं हुआ: ${e.message}")}finally{doc.close()}
    }
    private fun exportImage() {
        val width=1000;val rowH=90;val bmp=Bitmap.createBitmap(width,180+cells.size*rowH,Bitmap.Config.ARGB_8888)
        val canvas=Canvas(bmp);canvas.drawColor(Color.WHITE)
        val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=ink;textSize=34f}
        canvas.drawText("Notebook Hisab Calculator",35f,55f,p)
        val w=930f/columnCount;p.textSize=26f
        for(c in 0 until columnCount) canvas.drawText("Column ${c+1}",35f+c*w,115f,p)
        cells.forEachIndexed{r,row->for(c in 0 until columnCount)canvas.drawText(row[c].take(12),35f+c*w,165f+r*rowH,p)}
        val t=totals();for(c in 0 until columnCount)canvas.drawText(t[c]?.toString() ?: "REVIEW",35f+c*w,190f+cells.size*rowH,p)
        if(t.any{it==null}) canvas.drawText("GRAND TOTAL: REVIEW REQUIRED",35f,235f+cells.size*rowH,p) else canvas.drawText("GRAND TOTAL: ${t.fold(0L){a,v->a+(v?:0L)}}",35f,235f+cells.size*rowH,p)
        try{
            val values=android.content.ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,"Notebook-Hisab-${System.currentTimeMillis()}.png");put(MediaStore.Images.Media.MIME_TYPE,"image/png");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/NotebookHisab")}
            val uri=contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)!!
            contentResolver.openOutputStream(uri)!!.use{bmp.compress(Bitmap.CompressFormat.PNG,100,it)}
            toast("इमेज गैलरी में सेव हुई")
        }catch(e:Exception){toast("इमेज सेव नहीं हुई: ${e.message}")}
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
